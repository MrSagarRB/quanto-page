import React from "react";

const PanelistProfile = () => {
  return <div>PanelistProfile</div>;
};

export default PanelistProfile;
